DANAKITA ANDROID STARTER - BARU

Ini adalah source project Android, bukan APK siap instal.
Buka folder ini di Android Studio pada komputer untuk membangun APK.
Starter ini belum terhubung ke backend produksi, KYC, pembayaran, pencairan, atau sistem pinjaman nyata.
